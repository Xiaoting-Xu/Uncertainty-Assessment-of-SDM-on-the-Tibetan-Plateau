# 加载所需的库
library(raster)

##Set file location
path_folder = "D:/Public/Songyuxin/"
cropenvfolder = "D:/Public/Songyuxin/ESM/"

##Species
sp.list.bivar <- read.table(paste0(path_folder,"2species_bivar.txt"))
sp.list.bivar <- as.character(sp.list.bivar[,1])


######Gentiana yunnanensis#########
sp = sp.list.bivar[1]
sce <- c( "4GCMs_2060_245","4GCMs_2060_585","4GCMs_2100_245","4GCMs_2100_585")

for (i in sce) {
  # Input file and output file path
  current_tif <- file.path(cropenvfolder,sp,"baseline/baseline_thrESMpj.tif")
  future_filename <- paste0(i, "_thrESMpj.tif")
  future_tif <- file.path(cropenvfolder, sp, i, future_filename)
  # Read the tif file of the current species distribution
  current_raster <- raster(current_tif)
  # Read the tif file of the future species distribution
  future_raster <- raster(future_tif)
  # Change the current species distribution raster values of 0 to 1
  current_raster[current_raster == 0] <- -1
  # Calculate the current species distribution minus the future species distribution
  result_raster <- current_raster - future_raster
  ##Set the storage path
  file_path <- paste0(cropenvfolder, sp, "/",i,"_rangechange.tif")
  writeRaster(result_raster, filename=file_path, format="GTiff", overwrite=TRUE)
}



######Gentiana siphonantha#########
sp = sp.list.bivar[2]
sce <- c( "4GCMs_2060_245","4GCMs_2060_585","4GCMs_2100_245","4GCMs_2100_585")

for (i in sce) {
  # Input file and output file path
  current_tif <- file.path(cropenvfolder,sp,"baseline/baseline_thrESMpj.tif")
  future_filename <- paste0(i, "_thrESMpj.tif")
  future_tif <- file.path(cropenvfolder, sp, i, future_filename)
  # Read the tif file of the current species distribution
  current_raster <- raster(current_tif)
  # Read the tif file of the future species distribution
  future_raster <- raster(future_tif)
  # Change the current species distribution raster values of 0 to 1
  current_raster[current_raster == 0] <- -1
  # Calculate the current species distribution minus the future species distribution
  result_raster <- current_raster - future_raster
  ##Set the storage path
  file_path <- paste0(cropenvfolder, sp, "/",i,"_rangechange.tif")
  writeRaster(result_raster, filename=file_path, format="GTiff", overwrite=TRUE)
}