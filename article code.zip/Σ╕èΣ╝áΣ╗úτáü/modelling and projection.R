library(ecospat)
library(biomod2)
library(raster)
library(terra)
library(ggplot2)

##Set file location
path_folder = "D:/Public/Songyuxin/"
cropenvfolder = "D:/Public/Songyuxin/ESM/"



# Load climate data file
stk_clim <- stack(list.files(path = paste0(path_folder, "Variable/baseline"),
                             pattern = "Bio_", 
                             full.names = TRUE), 
                  RAT = FALSE)

# Extract specific layer
stk_clim_sub <- stack(subset(stk_clim, c("Bio_05", "Bio_06", "Bio_16", "Bio_17")))

# Load soil file
stk_crfvol <- stack(list.files(path = paste0(path_folder, "Variable"),
                               pattern = "CRFVOL", 
                               full.names = TRUE), 
                    RAT = FALSE)

# Merge two files
stk_current_sub <- stack(stk_clim_sub, stk_crfvol)


#########################################################################################################  
##SPECIES DISTRIBUTION MODEL
#########################################################################################################
# the list of species
sp.list.bivar <- read.table(paste0(path_folder,"2species_bivar.txt"))
sp.list.bivar <- as.character(sp.list.bivar[,1])

## get model parameters 
mod.id = "mod1"
mod.n.rep = 3

########### Gentiana yunnanensis ###########

sp = sp.list.bivar[1]
spif <- sub(" ",".",sp) #Replace the spaces between genus and species in the Latin names of species with dots

# creates unique filepath for temp directory
dir.create(file.path(paste("D:/Public/Songyuxin/ESM/data",sp)), showWarnings = FALSE)

# sets temp directory
rasterOptions(tmpdir=file.path(paste("D:/Public/Songyuxin/ESM/data",sp))) 

sp.occ <- read.table(paste0(path_folder, sp,"/",sp,"_distribution.csv"), header = TRUE, sep = ",")

setwd(paste0(cropenvfolder,sp,"/"))

##################################'SomersD' weighting######################################
## "ANN", "MARS", "RF" ,"MAXNET"########
## Convert the data into a format suitable for modeling
sp.form1 <- BIOMOD_FormatingData(resp.var = rep(1, nrow(sp.occ)), 
                                 expl.var = stk_current_sub,
                                 resp.xy = sp.occ[, c("X_WGS84", "Y_WGS84")],
                                 resp.name = sp, 
                                 PA.nb.rep = 1, 
                                 PA.nb.absences = 62,
                                 PA.strategy = "random")

## K-fold
mybiomodCV1 <- bm_CrossValidation(bm.format = sp.form1,
                                  k = 10,
                                  nb.rep = mod.n.rep)

### Calibration of simple bivariate models##
mod_1<-ecospat.ESM.Modeling( data = sp.form1,
                             modeling.id = mod.id,
                             models = c("ANN", "MARS", "RF" ,"MAXNET"),
                             DataSplitTable = mybiomodCV1,
                             weighting.score = c('SomersD'),
)
save(mod_1,file = paste0(cropenvfolder,sp,"/",sp,"_mod1"))

##### Ensemble Modeling
esm.mod1 <- ecospat.ESM.EnsembleModeling(ESM.modeling.output = mod_1, 
                                         weighting.score = c('SomersD'),
                                         models = c("ANN", "MARS", "RF" ,"MAXNET")
)
save(esm.mod1,file = paste0(cropenvfolder,sp,"/",sp,"_ESMmod1"))

##evaluation
esm.ev1 <- ecospat.ESM.EnsembleEvaluation(ESM.modeling.output = mod_1,
                                          ESM.EnsembleModeling.output = esm.mod1,
                                          metrics = c('Boyce','AUC')
)
save(esm.ev1,file = paste0(cropenvfolder,sp,"/",sp,"ESMevluation1"))
##The results of the evaluation
##esm.ev1$ESM.evaluations


#####"GAM","GLM"#######
sp.form2 <- BIOMOD_FormatingData(resp.var = rep(1, nrow(sp.occ)), 
                                 expl.var = stk_current_sub,
                                 resp.xy = sp.occ[, c("X_WGS84", "Y_WGS84")],
                                 resp.name = sp, 
                                 PA.nb.rep = 1, ##ecospat.ESM.Modeling 函数不支持使用多个伪缺失数据集，只能设置为1
                                 PA.nb.absences = 496,
                                 PA.strategy = "random")

## K-fold
mybiomodCV2 <- bm_CrossValidation(bm.format = sp.form2,
                                  k = 10,
                                  nb.rep = mod.n.rep)

### Calibration of simple bivariate models##
mod_2<-ecospat.ESM.Modeling( data = sp.form2,
                             modeling.id = mod.id,
                             models = c("GAM","GLM"),
                             DataSplitTable = mybiomodCV2,
                             weighting.score = c('SomersD'),
)
save(mod_2,file = paste0(cropenvfolder,sp,"/",sp,"_mod2"))

##### Ensemble Modeling
esm.mod2 <- ecospat.ESM.EnsembleModeling(ESM.modeling.output = mod_2, 
                                         weighting.score = c('SomersD'),
                                         models = c("GAM","GLM")
)
save(esm.mod2,file = paste0(cropenvfolder,sp,"/",sp,"_ESMmod2"))

##Evaluation
esm.ev2 <- ecospat.ESM.EnsembleEvaluation(ESM.modeling.output = mod_2,
                                          ESM.EnsembleModeling.output = esm.mod2,
                                          metrics = c('Boyce','AUC')
)
save(esm.ev2,file = paste0(cropenvfolder,sp,"/",sp,"ESMevluation2"))
##The results of the evaluation
##esm.ev2$ESM.evaluations



#######################################'Boyce' Weighting#################################
## "ANN", "MARS", "RF" ,"MAXNET"

mod_3<-ecospat.ESM.Modeling( data = sp.form1,
                             modeling.id = mod.id,
                             models = c("ANN", "MARS", "RF" ,"MAXNET"),
                             DataSplitTable = mybiomodCV1,
                             weighting.score = c('Boyce'),
)
save(mod_3,file = paste0(cropenvfolder,sp,"/",sp,"_mod3"))

##### Ensemble Modeling
esm.mod3 <- ecospat.ESM.EnsembleModeling(ESM.modeling.output = mod_3, 
                                         weighting.score = c('Boyce'),
                                         models = c("ANN", "MARS", "RF" ,"MAXNET")
)
save(esm.mod3,file = paste0(cropenvfolder,sp,"/",sp,"_ESMmod3"))

##Evaluation
esm.ev3 <- ecospat.ESM.EnsembleEvaluation(ESM.modeling.output = mod_3,
                                          ESM.EnsembleModeling.output = esm.mod3,
                                          metrics = c('Boyce','AUC')
)
save(esm.ev3,file = paste0(cropenvfolder,sp,"/",sp,"ESMevluation3"))
##The results of the evaluation
##esm.ev3$ESM.evaluations


#####"GAM","GLM"#######

mod_4<-ecospat.ESM.Modeling( data = sp.form2,
                             modeling.id = mod.id,
                             models = c("GAM","GLM"),
                             DataSplitTable = mybiomodCV2,
                             weighting.score = c('Boyce'),
)
save(mod_4,file = paste0(cropenvfolder,sp,"/",sp,"_mod4"))

##### Ensemble Modeling
esm.mod4 <- ecospat.ESM.EnsembleModeling(ESM.modeling.output = mod_4, 
                                         weighting.score = c('Boyce'),
                                         models = c("GAM","GLM")
)
save(esm.mod4,file = paste0(cropenvfolder,sp,"/",sp,"_ESMmod4"))

##Evaluation
esm.ev4 <- ecospat.ESM.EnsembleEvaluation(ESM.modeling.output = mod_4,
                                          ESM.EnsembleModeling.output = esm.mod4,
                                          metrics = c('Boyce','AUC')
)
save(esm.ev4,file = paste0(cropenvfolder,sp,"/",sp,"ESMevluation4"))
##The results of the evaluation
##esm.ev4$ESM.evaluations




########################Projection############################
## Define the required scenario
sce <- c("baseline",
         "ACCESS-CM2_2060_245","ACCESS-CM2_2060_585","ACCESS-CM2_2100_245","ACCESS-CM2_2100_585",
         "CMCC-ESM2_2060_245","CMCC-ESM2_2060_585","CMCC-ESM2_2100_245","CMCC-ESM2_2100_585",
         "MPI-ESM1-2-HR_2060_245","MPI-ESM1-2-HR_2060_585","MPI-ESM1-2-HR_2100_245","MPI-ESM1-2-HR_2100_585",
         "UKESM1-0-LL_2060_245","UKESM1-0-LL_2060_585","UKESM1-0-LL_2100_245","UKESM1-0-LL_2100_585",
         "4GCMs_2060_245","4GCMs_2060_585","4GCMs_2100_245","4GCMs_2100_585"
)

for (i in sce){
  dir_path <- paste0(cropenvfolder, sp, "/",i)
  dir.create(dir_path, recursive = TRUE)
  stk_clim <- stack(list.files(path = paste0(path_folder, "Variable/",i),
                               pattern = "Bio_", 
                               full.names = TRUE), 
                    RAT = FALSE)
  ##Climate data and soil data
  stk_clim_sub <- stack(subset(stk_clim, c("Bio_05", "Bio_06", "Bio_16", "Bio_17")))
  stk_current_sub <- stack(stk_clim_sub, stk_crfvol)
  ##Convert data format
  stk_current_sr <- rast(stk_current_sub)
  ###Due to the use of K-fold cross-validation, a new function "ecospat.ESM.Projection.new" was created for projection after adjusting the built-in code of "ecospat.ESM.Projection" function.
  pj <- ecospat.ESM.Projection.new(ESM.modeling.output = mod_4,####Select Boyce as the weight for the GLM (mod_4).
                                   new.env = stk_current_sr,
                                   models = c("GLM"))
  save(pj,file = paste0(cropenvfolder,sp,"/",i,"/",i,"_pj"))
  esm.pj <- ecospat.ESM.EnsembleProjection(ESM.prediction.output = pj,
                                           ESM.EnsembleModeling.output = esm.mod4,
                                           chosen.models = c("GLM"))
  save(esm.pj,file = paste0(cropenvfolder,sp,"/",i,"/",i,"_ESMpj"))
  tif_file <- paste0(cropenvfolder, sp,"/",i,"/",i,"_ESMpj.tif")
  writeRaster(esm.pj, filename = tif_file)
  
  ##threshold
  thr <- ecospat.ESM.threshold(esm.mod4)
  tss_th_value <- thr[thr$model == "Full_GLM_ESM", "TSS.th"]*1000
  reclass_matrix <- matrix(c(-Inf, tss_th_value, 0, tss_th_value, Inf, 1), ncol = 3, byrow = TRUE)
  r_reclassified <- classify(esm.pj, reclass_matrix)
  thrtif_file <- paste0(cropenvfolder, sp, "/",i,"/",i,"_thrESMpj.tif")
  writeRaster(r_reclassified, filename = thrtif_file)
}



########### Gentiana siphonantha##############################################

sp = sp.list.bivar[2]
spif <- sub(" ",".",sp) #Replace the spaces between genus and species in the Latin names of species with dots

# creates unique filepath for temp directory
dir.create(file.path(paste("D:/Public/Songyuxin/ESM/data",sp)), showWarnings = FALSE)

# sets temp directory
rasterOptions(tmpdir=file.path(paste("D:/Public/Songyuxin/ESM/data",sp))) 

sp.occ <- read.table(paste0(path_folder, sp,"/",sp,"_distribution.csv"), header = TRUE, sep = ",")

setwd(paste0(cropenvfolder,sp,"/"))

##################################'SomersD' weighting######################################
## "ANN", "MARS", "RF" ,"MAXNET"########
## Convert the data into a format suitable for modeling
sp.form1 <- BIOMOD_FormatingData(resp.var = rep(1, nrow(sp.occ)), 
                                 expl.var = stk_current_sub,
                                 resp.xy = sp.occ[, c("X_WGS84", "Y_WGS84")],
                                 resp.name = sp, 
                                 PA.nb.rep = 1, 
                                 PA.nb.absences = 62,
                                 PA.strategy = "random")

## K-fold
mybiomodCV1 <- bm_CrossValidation(bm.format = sp.form1,
                                  k = 10,
                                  nb.rep = mod.n.rep)

### Calibration of simple bivariate models##
mod_1<-ecospat.ESM.Modeling( data = sp.form1,
                             modeling.id = mod.id,
                             models = c("ANN", "MARS", "RF" ,"MAXNET"),
                             DataSplitTable = mybiomodCV1,
                             weighting.score = c('SomersD'),
)
save(mod_1,file = paste0(cropenvfolder,sp,"/",sp,"_mod1"))

##### Ensemble Modeling
esm.mod1 <- ecospat.ESM.EnsembleModeling(ESM.modeling.output = mod_1, 
                                         weighting.score = c('SomersD'),
                                         models = c("ANN", "MARS", "RF" ,"MAXNET")
)
save(esm.mod1,file = paste0(cropenvfolder,sp,"/",sp,"_ESMmod1"))

##evaluation
esm.ev1 <- ecospat.ESM.EnsembleEvaluation(ESM.modeling.output = mod_1,
                                          ESM.EnsembleModeling.output = esm.mod1,
                                          metrics = c('Boyce','AUC')
)
save(esm.ev1,file = paste0(cropenvfolder,sp,"/",sp,"ESMevluation1"))
##The results of the evaluation
##esm.ev1$ESM.evaluations


#####"GAM","GLM"#######
sp.form2 <- BIOMOD_FormatingData(resp.var = rep(1, nrow(sp.occ)), 
                                 expl.var = stk_current_sub,
                                 resp.xy = sp.occ[, c("X_WGS84", "Y_WGS84")],
                                 resp.name = sp, 
                                 PA.nb.rep = 1, ##ecospat.ESM.Modeling 函数不支持使用多个伪缺失数据集，只能设置为1
                                 PA.nb.absences = 496,
                                 PA.strategy = "random")

## K-fold
mybiomodCV2 <- bm_CrossValidation(bm.format = sp.form2,
                                  k = 10,
                                  nb.rep = mod.n.rep)

### Calibration of simple bivariate models##
mod_2<-ecospat.ESM.Modeling( data = sp.form2,
                             modeling.id = mod.id,
                             models = c("GAM","GLM"),
                             DataSplitTable = mybiomodCV2,
                             weighting.score = c('SomersD'),
)
save(mod_2,file = paste0(cropenvfolder,sp,"/",sp,"_mod2"))

##### Ensemble Modeling
esm.mod2 <- ecospat.ESM.EnsembleModeling(ESM.modeling.output = mod_2, 
                                         weighting.score = c('SomersD'),
                                         models = c("GAM","GLM")
)
save(esm.mod2,file = paste0(cropenvfolder,sp,"/",sp,"_ESMmod2"))

##Evaluation
esm.ev2 <- ecospat.ESM.EnsembleEvaluation(ESM.modeling.output = mod_2,
                                          ESM.EnsembleModeling.output = esm.mod2,
                                          metrics = c('Boyce','AUC')
)
save(esm.ev2,file = paste0(cropenvfolder,sp,"/",sp,"ESMevluation2"))
##The results of the evaluation
##esm.ev2$ESM.evaluations



#######################################'Boyce' Weighting#################################
## "ANN", "MARS", "RF" ,"MAXNET"

mod_3<-ecospat.ESM.Modeling( data = sp.form1,
                             modeling.id = mod.id,
                             models = c("ANN", "MARS", "RF" ,"MAXNET"),
                             DataSplitTable = mybiomodCV1,
                             weighting.score = c('Boyce'),
)
save(mod_3,file = paste0(cropenvfolder,sp,"/",sp,"_mod3"))

##### Ensemble Modeling
esm.mod3 <- ecospat.ESM.EnsembleModeling(ESM.modeling.output = mod_3, 
                                         weighting.score = c('Boyce'),
                                         models = c("ANN", "MARS", "RF" ,"MAXNET")
)
save(esm.mod3,file = paste0(cropenvfolder,sp,"/",sp,"_ESMmod3"))

##Evaluation
esm.ev3 <- ecospat.ESM.EnsembleEvaluation(ESM.modeling.output = mod_3,
                                          ESM.EnsembleModeling.output = esm.mod3,
                                          metrics = c('Boyce','AUC')
)
save(esm.ev3,file = paste0(cropenvfolder,sp,"/",sp,"ESMevluation3"))
##The results of the evaluation
##esm.ev3$ESM.evaluations


#####"GAM","GLM"#######

mod_4<-ecospat.ESM.Modeling( data = sp.form2,
                             modeling.id = mod.id,
                             models = c("GAM","GLM"),
                             DataSplitTable = mybiomodCV2,
                             weighting.score = c('Boyce'),
)
save(mod_4,file = paste0(cropenvfolder,sp,"/",sp,"_mod4"))

##### Ensemble Modeling
esm.mod4 <- ecospat.ESM.EnsembleModeling(ESM.modeling.output = mod_4, 
                                         weighting.score = c('Boyce'),
                                         models = c("GAM","GLM")
)
save(esm.mod4,file = paste0(cropenvfolder,sp,"/",sp,"_ESMmod4"))

##Evaluation
esm.ev4 <- ecospat.ESM.EnsembleEvaluation(ESM.modeling.output = mod_4,
                                          ESM.EnsembleModeling.output = esm.mod4,
                                          metrics = c('Boyce','AUC')
)
save(esm.ev4,file = paste0(cropenvfolder,sp,"/",sp,"ESMevluation4"))
##The results of the evaluation
##esm.ev4$ESM.evaluations




########################Projection############################
## Define the required scenario
sce <- c("baseline",
         "ACCESS-CM2_2060_245","ACCESS-CM2_2060_585","ACCESS-CM2_2100_245","ACCESS-CM2_2100_585",
         "CMCC-ESM2_2060_245","CMCC-ESM2_2060_585","CMCC-ESM2_2100_245","CMCC-ESM2_2100_585",
         "MPI-ESM1-2-HR_2060_245","MPI-ESM1-2-HR_2060_585","MPI-ESM1-2-HR_2100_245","MPI-ESM1-2-HR_2100_585",
         "UKESM1-0-LL_2060_245","UKESM1-0-LL_2060_585","UKESM1-0-LL_2100_245","UKESM1-0-LL_2100_585",
         "4GCMs_2060_245","4GCMs_2060_585","4GCMs_2100_245","4GCMs_2100_585"
)

for (i in sce){
  dir_path <- paste0(cropenvfolder, sp, "/",i)
  dir.create(dir_path, recursive = TRUE)
  stk_clim <- stack(list.files(path = paste0(path_folder, "Variable/",i),
                               pattern = "Bio_", 
                               full.names = TRUE), 
                    RAT = FALSE)
  ##Climate data and soil data
  stk_clim_sub <- stack(subset(stk_clim, c("Bio_05", "Bio_06", "Bio_16", "Bio_17")))
  stk_current_sub <- stack(stk_clim_sub, stk_crfvol)
  ##Convert data format
  stk_current_sr <- rast(stk_current_sub)
  ###Due to the use of K-fold cross-validation, a new function "ecospat.ESM.Projection.new" was created for projection after adjusting the built-in code of "ecospat.ESM.Projection" function.
  pj <- ecospat.ESM.Projection.new(ESM.modeling.output = mod_3,####Select Boyce as the weight for the MAXNET (mod_3).
                                   new.env = stk_current_sr,
                                   models = c("MAXNET"))
  save(pj,file = paste0(cropenvfolder,sp,"/",i,"/",i,"_pj"))
  esm.pj <- ecospat.ESM.EnsembleProjection(ESM.prediction.output = pj,
                                           ESM.EnsembleModeling.output = esm.mod3,
                                           chosen.models = c("MAXNET"))
  save(esm.pj,file = paste0(cropenvfolder,sp,"/",i,"/",i,"_ESMpj"))
  tif_file <- paste0(cropenvfolder, sp,"/",i,"/",i,"_ESMpj.tif")
  writeRaster(esm.pj, filename = tif_file)
  
  ##threshold
  thr <- ecospat.ESM.threshold(esm.mod3)
  tss_th_value <- thr[thr$model == "Full_MAXNET_ESM", "TSS.th"]*1000
  reclass_matrix <- matrix(c(-Inf, tss_th_value, 0, tss_th_value, Inf, 1), ncol = 3, byrow = TRUE)
  r_reclassified <- classify(esm.pj, reclass_matrix)
  thrtif_file <- paste0(cropenvfolder, sp, "/",i,"/",i,"_thrESMpj.tif")
  writeRaster(r_reclassified, filename = thrtif_file)
}